/** Automatically generated file. DO NOT MODIFY */
package com.example.fileuploadapi21.benjung;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}